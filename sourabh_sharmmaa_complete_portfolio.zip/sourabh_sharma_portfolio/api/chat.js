// Vercel serverless endpoint for the portfolio chatbot.
module.exports = async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Method not allowed." });
  }
  const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
  if (!message || message.length > 1000) {
    return res.status(400).json({ error: "Please enter a message of up to 1000 characters." });
  }
  if (!process.env.GROQ_API_KEY) {
    return res.status(503).json({ error: "Chatbot is not configured yet. Add GROQ_API_KEY to your .env file." });
  }
  try {
    const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: { "Authorization": `Bearer ${process.env.GROQ_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: process.env.GROQ_MODEL || "openai/gpt-oss-20b",
        messages: [
          { role: "system", content: "You are the portfolio assistant for Sourabh Sharma. The portfolio describes him as a BTech student interested in AI and machine learning, learning C, beginner C++, Python, HTML, CSS, and JavaScript. Be helpful and honest. Do not invent personal details, contact information, completed projects, or skill proficiency not stated here. If asked for missing details, say they have not been added to the portfolio yet." },
          { role: "user", content: message }
        ],
        temperature: 0.5,
        max_tokens: 500
      })
    });
    const data = await response.json();
    if (!response.ok) return res.status(502).json({ error: data.error?.message || "The AI service is unavailable." });
    const reply = data.choices?.[0]?.message?.content;
    if (typeof reply !== "string" || !reply.trim()) return res.status(502).json({ error: "The AI returned an empty response." });
    return res.status(200).json({ reply: reply.trim() });
  } catch (error) {
    return res.status(500).json({ error: "Could not connect to the AI service. Please try again." });
  }
};
