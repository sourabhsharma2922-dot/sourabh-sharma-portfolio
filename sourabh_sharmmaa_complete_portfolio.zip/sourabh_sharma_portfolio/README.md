# Sourabh Sharma Portfolio

## Run in VS Code

1. Extract this folder and open it in VS Code.
2. Install Node.js if needed.
3. Copy `.env.example` to `.env`.
4. Create a fresh Groq API key and put it in `.env` as `GROQ_API_KEY=...`.
5. Install the Vercel CLI: `npm install -g vercel`
6. Run `vercel dev` from this project folder.
7. Open the local URL shown in the terminal.

The portfolio is static HTML/CSS/JS, but the chatbot uses `/api/chat`; run `vercel dev` for the chatbot to work. The theme toggle and page layout work without the chatbot API.

## Personal details

GitHub, email, and LinkedIn are placeholders because the original website contained another person's contact details. Replace them in `index.html` with your own information before publishing.

## API key safety

Never commit `.env` or share your API key. Use a fresh key; do not reuse a key that has been shared in a chat or public location.
