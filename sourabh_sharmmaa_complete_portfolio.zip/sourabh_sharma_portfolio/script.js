// Handles the mobile menu and the light/dark theme toggle.
const navToggle = document.querySelector(".nav-toggle");
const primaryNav = document.querySelector("#primary-nav");
const navLinks = document.querySelectorAll("#primary-nav a");
const themeToggle = document.querySelector("#theme-toggle");
const THEME_KEY = "portfolio-theme";

function setMenuState(isOpen) {
  primaryNav.classList.toggle("is-open", isOpen);
  navToggle.setAttribute("aria-expanded", String(isOpen));
  navToggle.setAttribute("aria-label", isOpen ? "Close menu" : "Open menu");
}

if (navToggle && primaryNav) {
  navToggle.addEventListener("click", () => {
    const isOpen = !primaryNav.classList.contains("is-open");
    setMenuState(isOpen);
  });

  // Close the menu after a section link is chosen.
  navLinks.forEach((link) => {
    link.addEventListener("click", () => setMenuState(false));
  });
}

function getSavedTheme() {
  try {
    const savedTheme = localStorage.getItem(THEME_KEY);
    if (savedTheme === "light" || savedTheme === "dark") {
      return savedTheme;
    }
  } catch (error) {
    // localStorage can be blocked in some browsers.
  }
  return "dark";
}

function updateThemeButton(theme) {
  if (!themeToggle) {
    return;
  }

  const isDark = theme === "dark";
  const nextTheme = isDark ? "light" : "dark";
  const label = themeToggle.querySelector(".theme-toggle-text");

  themeToggle.setAttribute("aria-pressed", String(isDark));
  themeToggle.setAttribute("aria-label", "Switch to " + nextTheme + " mode");

  if (label) {
    label.textContent = isDark ? "Light" : "Dark";
  }
}

function applyTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme);

  try {
    localStorage.setItem(THEME_KEY, theme);
  } catch (error) {
    // The theme still changes for this visit even if saving fails.
  }

  updateThemeButton(theme);
}

applyTheme(getSavedTheme());

if (themeToggle) {
  themeToggle.addEventListener("click", () => {
    const currentTheme = document.documentElement.getAttribute("data-theme");
    const nextTheme = currentTheme === "light" ? "dark" : "light";
    applyTheme(nextTheme);
  });
}

/* =========================
   AI CHATBOT
   ========================= */

const chatForm = document.querySelector("#chat-form");
const chatInput = document.querySelector("#chat-input");
const chatMessages = document.querySelector("#chat-messages");
const chatStatus = document.querySelector("#chat-status");
const chatSend = document.querySelector("#chat-send");

function addChatMessage(message, sender) {
  const messageElement = document.createElement("p");

  messageElement.classList.add("chat-message");
  messageElement.classList.add(
    sender === "user" ? "user-message" : "assistant-message"
  );

  // textContent displays text safely instead of interpreting HTML.
  messageElement.textContent = message;

  chatMessages.appendChild(messageElement);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

if (
  chatForm &&
  chatInput &&
  chatMessages &&
  chatStatus &&
  chatSend
) {
  chatForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const userMessage = chatInput.value.trim();

    if (!userMessage) {
      chatStatus.textContent = "Please enter a message.";
      return;
    }

    addChatMessage(userMessage, "user");
    chatInput.value = "";
    chatSend.disabled = true;
    chatStatus.textContent = "AI is thinking...";

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          message: userMessage
        })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(
          data.error || "The AI service is unavailable."
        );
      }

      if (typeof data.reply !== "string" || !data.reply.trim()) {
        throw new Error("The AI returned an empty response.");
      }

      addChatMessage(data.reply, "assistant");
      chatStatus.textContent = "AI assistant ready";
    } catch (error) {
      addChatMessage(
        error.message || "Something went wrong. Please try again.",
        "assistant"
      );

      chatStatus.textContent =
        "Message failed. Please try again.";
    } finally {
      chatSend.disabled = false;
      chatInput.focus();
    }
  });
}
